public class RoadAccidentReport extends RoadAccidents{

    public RoadAccidents (String vehicleType, String city, int accidentTotal) {
        super (RoadAccidents);
    }
}

public abstract class RoadAccidents {
    String vehicleType;
    String city;
    int accidentTotal;

    public RoadAccidents (String vehicleType, String city, int accidentTotal) {
        this.accidentTotal =accidentTotal;
        this.city = city;
        this.accidentTotal = accidentTotal;
    }

    public String getVihicleType() {
        return vehicleType;
    }
    public String getCity() {
        return city;
    }
    public int getAccidentTotal() {
        return accidentTotal;
    }
}

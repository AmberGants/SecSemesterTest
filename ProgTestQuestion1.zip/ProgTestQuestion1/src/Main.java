//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        String[] vehicles = {"Car", "Motor Bike"};
        String[] cities = {"Cape Town", "Johannesburg", "Port Elizabeth"};
        int[][]  roadAccidents = {
                {155, 178, 112},
                {121, 145, 89}
        };

        System.out.println("Enter the number of car accidents for  " + cities[0] + ": "  + roadAccidents[0][0]);
        System.out.println("Enter the number of moto bike accidents for  " + cities[0] + ": "  + roadAccidents[1][0]);
        System.out.println("Enter the number of car accidents for " + cities[1] + ": "  + roadAccidents[0][1]);
        System.out.println("Enter the number of moto bike accidents for" + cities[1] + ": " + roadAccidents[1][1]);
        System.out.println("Enter the number of car accidents for " + cities[2] + ": " + roadAccidents[0][2]);
        System.out.println("Enter the number of moto bike accidents for " + cities[2] + ": " + roadAccidents[1][2]);


        System.out.println("-------------------------------------------------------------------");
        System.out.println("ROAD ACCIDENT REPORT");
        System.out.println("-------------------------------------------------------------------");

        for (String vehicle : vehicles) {
            System.out.print("\t\t\t\t");
            System.out.print(vehicle + "\t\t\t");
        }
        System.out.println();
        for (int i = 0; i < cities.length; i++) {
            System.out.print(cities[i] + "\t\t");
            for (int j = 0; j < vehicles.length; j++) {
                System.out.print( "\t\t" + roadAccidents[j][i] + "\t\t");
            }
            System.out.println( );
        }
        System.out.println("-------------------------------------------------------------------");
        System.out.println("ROAD ACCIDENT TOTAL FOR EACH REPORT");
        System.out.println("-------------------------------------------------------------------");

        for (int i = 0; i < cities.length; i++) {
            int total = 0;
            for (int[] roadAccident : roadAccidents) {
                total += roadAccident[i];

            }
            for (int j = 0; j < roadAccidents.length; j++) {
                total += roadAccidents[j][i];
            }
            System.out.println(cities[i] + "\t\t " + total);
        }
    }
}